<?xml version="1.0" encoding="${default-encoding}"?>

<!-- New MathML document created with EditiX XML Editor (http://www.editix.com) at ${date} -->

<math xmlns="http://www.w3.org/1998/Math/MathML">
${cursor}
</math>