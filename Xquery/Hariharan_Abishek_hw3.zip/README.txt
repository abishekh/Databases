README
Name:Abishek Hariharan
USC-ID:2743190572
email:abishekh@usc.edu 

Files included:
company.xml
company.xsd
company.xsl
query1.xquery
query2.xquery
query3.xquery
query4.xquery
query5.xquery
query6.xquery
README.txt
