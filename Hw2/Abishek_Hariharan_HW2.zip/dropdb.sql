drop index building_idx;
drop index student_idx;
drop index trampoint_idx;
drop index tram_idx;


 delete from user_sdo_geom_metadata;

 	drop table trampoint;
 	drop table tramstop;
 	drop table student;
 	drop table building;