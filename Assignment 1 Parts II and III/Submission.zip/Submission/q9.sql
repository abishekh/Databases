SELECT VO1 AS VillaOwnerID, (VacantVillas/TotalOwned) AS VacancyRatio FROM  (SELECT T4.VOwner AS VO2,count(T4.VillaID)AS TotalOwned FROM Villa AS T4 GROUP BY T4.VOwner)AS T4,
(SELECT T1.VOwner AS VO1 ,count(DISTINCT T1.`VillaID`) AS VacantVillas FROM Villa AS T1 WHERE T1.`VillaID` IN 
(SELECT DISTINCT T2.villaID FROM reservation AS T2 WHERE T2.villaID NOT IN (SELECT T3.villaID FROM reservation AS T3 WHERE T3.startDate <= '2014-08-15' AND T3.`endDate`>='2014-08-15')
)GROUP BY T1.`VOwner` )AS T1  WHERE VO1 = VO2;