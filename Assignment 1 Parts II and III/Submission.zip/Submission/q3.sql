SELECT DISTINCT userID,Fname,Lname FROM reservation WHERE reservationNo IN (SELECT reservationNo FROM couponsapplied WHERE `CouponCode` IN (SELECT CouponCode FROM Coupon WHERE Discount >10));
