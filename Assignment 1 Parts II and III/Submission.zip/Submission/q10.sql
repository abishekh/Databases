SELECT Person.Fname,Person.`Lname`,T1.`userID`,T1.`reservationNo` AS FirstReservationID,T2.`reservationNo`AS SecondReservationID FROM Person,reservation T1, reservation T2 WHERE
 (T2.`startDate` BETWEEN T1.`startDate` AND T1.`endDate` AND T1.`villaID` != T2.`villaID` AND T1.`userID`=T2.`userID` AND Person.`userID`=T1.`userID`);
