Name : Abishek Hariharan
USC ID : 2743190572

Assumptions and Explanations

This assignment has been done in MySQL Using Sequel Pro for Mac Version 1.0.2

User Table has been implemented as Person for future design considerations.
Other modifications have been made with permission (see: https://courses.uscden.net/d2l/le/7183/discussions/threads/601/View )

Primary Keys  and Foreign Key data have been altered to numeric type since this is what the class mentions as good practice for Primary keys.

Instead of the CEO not managed by anyone, it has been set so that he manages himself.

Separate tables have been created only for multi value attributes.These include 'features','Phone','couponsapplied','VOwner','likedreviews'