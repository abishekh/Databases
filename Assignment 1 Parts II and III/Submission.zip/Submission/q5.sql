SELECT AVG(DATE_FORMAT(NOW(), '%Y') - DATE_FORMAT(DoB, '%Y') - (DATE_FORMAT(NOW(), '00-%m-%d') < DATE_FORMAT(DoB, '00-%m-%d'))) AS Average_Age FROM Person
 WHERE userID IN(SELECT  DISTINCT userID FROM reservation WHERE startDate <='2013-09-01' AND endDate<='2014-01-01');
