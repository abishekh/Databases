SELECT villaID,datediff(`endDate`,`startDate`)daysrented FROM reservation WHERE datediff(`endDate`,`startDate`) IN (SELECT MAX(datediff(`endDate`,`startDate`)) AS daysrented FROM reservation  WHERE startDate AND endDate BETWEEN '2014-01-01' AND '2014-12-31' ) AND startDate AND endDate BETWEEN '2014-01-01' AND '2014-12-30';

