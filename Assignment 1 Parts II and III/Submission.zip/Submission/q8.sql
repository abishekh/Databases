SELECT Review.`userID`AS TopreviewerID FROM likedreviews 
INNER JOIN Review ON Review.`reviewID`=likedreviews.`reviewID` GROUP BY Review.`userID` ORDER BY count(likedreviews.`reviewID`) DESC LIMIT 1;